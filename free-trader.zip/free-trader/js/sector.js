import { createRng } from './dice.js';

const PSEUDO_HEX_DIGITS = '0123456789ABCDEFGHJKLMNPQRSTUVWXYZ';
const STARPORT_BY_ROLL = { 2: 'X', 3: 'E', 4: 'E', 5: 'D', 6: 'D', 7: 'C', 8: 'C', 9: 'B', 10: 'B', 11: 'A' };

const clamp = (value, low, high) => Math.min(high, Math.max(low, value));
const between = (value, low, high) => value >= low && value <= high;

const TECH_LEVEL_DMS = {
  starport: (starport) => ({ A: 6, B: 4, C: 2, X: -4 })[starport] ?? 0,
  size: (size) => [2, 2, 1, 1, 1][size] ?? 0,
  atmosphere: (atmosphere) => (atmosphere <= 3 || atmosphere >= 10 ? 1 : 0),
  hydrographics: (hydrographics) => ({ 0: 1, 9: 1, 10: 2 })[hydrographics] ?? 0,
  population: (population) => (between(population, 1, 5) ? 1 : ({ 9: 1, 10: 2 })[population] ?? 0),
  government: (government) => ({ 0: 1, 5: 1, 7: 2, 13: -2, 14: -2 })[government] ?? 0,
};

const TRADE_CODE_RULES = {
  Ag: (w) => between(w.atmosphere, 4, 9) && between(w.hydrographics, 4, 8) && between(w.population, 5, 7),
  As: (w) => w.size === 0 && w.atmosphere === 0 && w.hydrographics === 0,
  Ba: (w) => w.population === 0 && w.government === 0 && w.lawLevel === 0,
  De: (w) => w.atmosphere >= 2 && w.hydrographics === 0,
  Fl: (w) => w.atmosphere >= 10 && w.hydrographics >= 1,
  Ga: (w) => [5, 6, 8].includes(w.atmosphere) && between(w.hydrographics, 4, 9) && between(w.population, 4, 8),
  Hi: (w) => w.population >= 9,
  Ht: (w) => w.techLevel >= 12,
  Ic: (w) => w.atmosphere <= 1 && w.hydrographics >= 1,
  In: (w) => [0, 1, 2, 4, 7, 9].includes(w.atmosphere) && w.population >= 9,
  Lo: (w) => between(w.population, 1, 3),
  Lt: (w) => w.techLevel <= 5,
  Na: (w) => w.atmosphere <= 3 && w.hydrographics <= 3 && w.population >= 6,
  Ni: (w) => between(w.population, 4, 6),
  Po: (w) => between(w.atmosphere, 2, 5) && w.hydrographics <= 3,
  Ri: (w) => [6, 8].includes(w.atmosphere) && between(w.population, 6, 8),
  Wa: (w) => w.hydrographics === 10,
  Va: (w) => w.atmosphere === 0,
};

function generateWorld(column, row, rng, gasGiantTarget) {
  const roll2d6 = () => rng.rollDice(2);

  const size = roll2d6() - 2;
  const atmosphere = size === 0 ? 0 : clamp(roll2d6() - 7 + size, 0, 15);
  const hydrographicsDM = ([0, 1, 10, 11, 12].includes(atmosphere) ? -4 : 0) + (atmosphere === 14 ? -2 : 0);
  const hydrographics = size <= 1 ? 0 : clamp(roll2d6() - 7 + size + hydrographicsDM, 0, 10);

  const populationDM =
    (size <= 2 ? -1 : 0) + (atmosphere >= 10 ? -2 : 0) + (atmosphere === 6 ? 3 : 0) +
    ([5, 8].includes(atmosphere) ? 1 : 0) + (hydrographics === 0 && atmosphere < 3 ? -2 : 0);
  const population = clamp(roll2d6() - 2 + populationDM, 0, 10);

  const starport = STARPORT_BY_ROLL[clamp(roll2d6() - 7 + population, 2, 11)];
  const government = population === 0 ? 0 : clamp(roll2d6() - 7 + population, 0, 15);
  const lawLevel = government === 0 ? 0 : Math.max(0, roll2d6() - 7 + government);

  const techLevelDM =
    TECH_LEVEL_DMS.starport(starport) + TECH_LEVEL_DMS.size(size) + TECH_LEVEL_DMS.atmosphere(atmosphere) +
    TECH_LEVEL_DMS.hydrographics(hydrographics) + TECH_LEVEL_DMS.population(population) + TECH_LEVEL_DMS.government(government);
  const techLevel = population === 0 ? 0 : Math.max(0, rng.rollDice(1) + techLevelDM);

  const world = {
    id: `${String(column).padStart(2, '0')}${String(row).padStart(2, '0')}`,
    column, row, starport, size, atmosphere, hydrographics, population, government, lawLevel, techLevel,
    hasGasGiant: roll2d6() >= gasGiantTarget,
  };
  const digit = (value) => PSEUDO_HEX_DIGITS[value];
  world.uwp = `${starport}${digit(size)}${digit(atmosphere)}${digit(hydrographics)}${digit(population)}${digit(government)}${digit(lawLevel)}-${digit(techLevel)}`;
  world.tradeCodes = Object.keys(TRADE_CODE_RULES).filter((code) => TRADE_CODE_RULES[code](world));
  return world;
}

/** Generates a subsector-sized grid of worlds from the seed in rules.jsonc. */
export function generateSector(rules) {
  const rng = createRng(`${rules.seed}|sector`);
  const { columns, rows, systemChance, gasGiantTarget } = rules.sector;
  const worlds = [];
  for (let column = 1; column <= columns; column++) {
    for (let row = 1; row <= rows; row++) {
      if (rng.chance(systemChance)) worlds.push(generateWorld(column, row, rng, gasGiantTarget));
    }
  }
  return { worlds };
}

/** Distance in parsecs between two hexes (columns offset by half a hex, odd columns shifted down). */
export function hexDistance(from, to) {
  const toCube = ({ column, row }) => {
    const z = row - (column - (column & 1)) / 2;
    return { x: column, y: -column - z, z };
  };
  const a = toCube(from);
  const b = toCube(to);
  return Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y), Math.abs(a.z - b.z));
}
