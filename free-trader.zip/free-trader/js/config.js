const CONFIG_NAMES = ['rules', 'goods', 'ship'];

/** Loads config/*.jsonc. Full-line // comments are stripped before parsing. */
export async function loadConfig() {
  const config = {};
  for (const name of CONFIG_NAMES) {
    const response = await fetch(`config/${name}.jsonc`);
    if (!response.ok) throw new Error(`Could not load config/${name}.jsonc (${response.status}).`);
    const textWithoutComments = (await response.text()).replace(/^\s*\/\/.*$/gm, '');
    try {
      config[name] = JSON.parse(textWithoutComments);
    } catch (error) {
      throw new Error(`config/${name}.jsonc is not valid: ${error.message}. Comments must be on their own line.`);
    }
  }
  return config;
}
