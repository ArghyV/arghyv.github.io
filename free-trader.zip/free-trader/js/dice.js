function hashText(text) {
  let hash = 2166136261;
  for (const character of text) hash = Math.imul(hash ^ character.charCodeAt(0), 16777619);
  return hash >>> 0;
}

/** Deterministic random source: the same seed text always yields the same sequence. */
export function createRng(seedText) {
  let state = hashText(seedText);
  const nextFraction = () => {
    state = (state + 0x6D2B79F5) | 0;
    let mixed = Math.imul(state ^ (state >>> 15), 1 | state);
    mixed = (mixed + Math.imul(mixed ^ (mixed >>> 7), 61 | mixed)) ^ mixed;
    return ((mixed ^ (mixed >>> 14)) >>> 0) / 4294967296;
  };
  const rollDice = (count) => {
    let total = 0;
    for (let die = 0; die < count; die++) total += 1 + Math.floor(nextFraction() * 6);
    return total;
  };
  return {
    rollDice,
    chance: (probability) => nextFraction() < probability,
    pick: (items) => items[Math.floor(nextFraction() * items.length)],
  };
}

/** Rolls notation such as "2d6" or "3d6x5" (dice count, optional multiplier). */
export function rollNotation(rng, notation) {
  const [, diceCount, multiplier = '1'] = notation.match(/^(\d+)d6(?:x(\d+))?$/);
  return rng.rollDice(Number(diceCount)) * Number(multiplier);
}
