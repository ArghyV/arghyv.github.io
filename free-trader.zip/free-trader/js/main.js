import { loadConfig } from './config.js';
import { generateSector, hexDistance } from './sector.js';
import { createGame, createNewState, formatCredits } from './game.js';

const SAVE_KEY = 'free-trader-save';
const app = document.getElementById('app');

const table = (headers, rows) =>
  `<div class="scroll"><table><tr>${headers.map((header) => `<th>${header}</th>`).join('')}</tr>${rows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')}</table></div>`;

function loadSavedState(seed) {
  try {
    const saved = JSON.parse(localStorage.getItem(SAVE_KEY));
    return saved?.seed === seed ? saved.state : null;
  } catch { return null; }
}

function renderMarket(game) {
  const world = game.currentWorld();
  const lotsByName = new Map(game.marketLots(world).map((lot) => [lot.good.name, lot]));
  const rows = game.allGoods
    .filter((good) => lotsByName.has(good.name) || game.state.cargo[good.name])
    .map((good) => {
      const lot = lotsByName.get(good.name);
      const held = game.state.cargo[good.name];
      return [
        good.name, lot ? lot.tonsAvailable : 0, lot ? formatCredits(lot.buyPrice) : '-',
        held ? `${held.tons}t @ ${formatCredits(held.totalCost / held.tons)}` : '-', formatCredits(game.pricePerTon(good, world, 'sell')),
        `<input type="number" min="1" value="1" aria-label="tons of ${good.name}"> <button data-action="buy" data-good="${good.name}">Buy</button> <button data-action="sell" data-good="${good.name}">Sell</button>`,
      ];
    });
  return table(['Good', 'For sale (t)', 'Buy/t', 'Held', 'Sell/t here', 'Trade'], rows);
}

function renderDestinations(game, config) {
  const here = game.currentWorld();
  const rows = game.state.gameOver ? [] : config.ship && game.worldsNearby(here).map(({ world, distance }) => [
    world.id, world.uwp, world.tradeCodes.join(' '), world.hasGasGiant ? 'GG' : '', distance,
    distance <= config.ship.jumpRating ? `<button data-action="jump" data-world="${world.id}">Jump</button>` : 'out of range',
  ]);
  return table(['World', 'UWP', 'Codes', 'Gas giant', 'Parsecs', ''], rows);
}

function render(game, config) {
  const { state } = game;
  const world = game.currentWorld();
  const costs = game.monthlyCosts();
  const fuelButtons = Object.entries(game.FUEL_SOURCES)
    .filter(([, source]) => source.available(world))
    .map(([name, source]) => `<button data-action="refuel" data-source="${name}">${source.label}</button>`).join(' ');
  app.innerHTML = `
    <h1>Free Trader</h1>
    <p>Day ${state.day} | Cash ${formatCredits(state.cash)} | Fuel ${state.fuel.tons}t (${state.fuel.refined ? 'refined' : 'unrefined'}) | Cargo ${game.cargoTons()}/${config.ship.cargoTons}t</p>
    <p>At ${world.id} ${world.uwp} ${world.tradeCodes.join(' ')} | Monthly bills ${formatCredits(Object.values(costs).reduce((a, b) => a + b, 0))}</p>
    ${state.gameOver ? `<p><strong>${state.gameOver}</strong></p>` : ''}
    <h2>Market</h2>${renderMarket(game)}
    <h2>Fuel</h2><p>${fuelButtons || 'No fuel available here.'}</p>
    <h2>Destinations</h2>${renderDestinations(game, config)}
    <h2>Log</h2><div id="log">${state.log.slice(0, 30).join('\n')}</div>
    <p><button data-action="new-game">New game</button></p>`;
}

async function start() {
  const config = await loadConfig();
  const sector = generateSector(config.rules);
  let game = createGame(config, sector, loadSavedState(config.rules.seed) ?? createNewState(config, sector));
  game.worldsNearby = (here) => sector.worlds
    .filter((world) => world !== here)
    .map((world) => ({ world, distance: hexDistance(here, world) }))
    .filter(({ distance }) => distance <= config.ship.jumpRating + 2)
    .sort((a, b) => a.distance - b.distance);

  app.addEventListener('click', (event) => {
    const { action, good, world, source } = event.target.dataset;
    if (!action) return;
    if (action === 'new-game') {
      game = createGame(config, sector, createNewState(config, sector));
      game.worldsNearby = (here) => sector.worlds.filter((w) => w !== here).map((w) => ({ world: w, distance: hexDistance(here, w) })).filter(({ distance }) => distance <= config.ship.jumpRating + 2).sort((a, b) => a.distance - b.distance);
    } else {
      try {
        const tons = Number(event.target.closest('tr')?.querySelector('input')?.value);
        if (action === 'buy') game.buy(good, tons);
        if (action === 'sell') game.sell(good, tons);
        if (action === 'refuel') game.refuel(source);
        if (action === 'jump') game.jump(world);
      } catch (error) {
        game.state.log.unshift(`Day ${game.state.day}: ${error.message}`);
      }
    }
    localStorage.setItem(SAVE_KEY, JSON.stringify({ seed: config.rules.seed, state: game.state }));
    render(game, config);
  });
  render(game, config);
}

start().catch((error) => { app.textContent = error.message; });
