import { createRng, rollNotation } from './dice.js';
import { hexDistance } from './sector.js';

const sum = (numbers) => numbers.reduce((total, number) => total + number, 0);
const requireThat = (condition, message) => { if (!condition) throw new Error(message); };
export const formatCredits = (amount) => `Cr${Math.round(amount).toLocaleString('en-US')}`;

export function createNewState(config, sector) {
  const { jumpRating } = config.ship;
  const hasNeighbour = (world) => sector.worlds.some((other) => other !== world && hexDistance(world, other) <= jumpRating);
  const home = sector.worlds.find((world) => 'AB'.includes(world.starport) && hasNeighbour(world)) ?? sector.worlds[0];
  return {
    day: 0, cash: config.ship.startingCash, locationId: home.id,
    fuel: { tons: config.ship.fuelTons, refined: false },
    cargo: {}, purchasedTons: {}, eventCount: 0, billedMonths: 0, gameOver: null,
    log: [`Day 0: docked at ${home.id}.`],
  };
}

/** All game rules. Mutates `state`; every action throws an Error with a player-readable message when refused. */
export function createGame(config, sector, state) {
  const { rules, goods, ship } = config;
  const allGoods = [...goods.common, ...goods.trade];
  const worldById = (id) => sector.worlds.find((world) => world.id === id);
  const currentWorld = () => worldById(state.locationId);
  const currentMonth = () => Math.floor(state.day / rules.daysPerMonth);
  const log = (message) => state.log.unshift(`Day ${state.day}: ${message}`);
  const cargoTons = () => sum(Object.values(state.cargo).map((held) => held.tons));

  const largestDM = (dmByTradeCode, world) => Math.max(0, ...world.tradeCodes.map((code) => dmByTradeCode?.[code] ?? 0));

  function pricePerTon(good, world, side) {
    const rng = createRng(`${rules.seed}|price|${world.id}|${currentMonth()}|${good.name}|${side}`);
    const [favourableDMs, unfavourableDMs] = side === 'buy' ? [good.buy, good.sell] : [good.sell, good.buy];
    const check = rng.rollDice(2) + rules.brokerSkill + largestDM(favourableDMs, world) - largestDM(unfavourableDMs, world);
    const [purchasePercent, salePercent] = rules.priceTable[Math.min(16, Math.max(2, check))];
    return Math.round((good.basePrice * (side === 'buy' ? purchasePercent : salePercent)) / 100);
  }

  const purchaseKey = (world, good) => `${world.id}|${currentMonth()}|${good.name}`;

  /** This month's goods for sale at a world: fixed per world and month, reduced by what the player already bought. */
  function marketLots(world) {
    const rng = createRng(`${rules.seed}|market|${world.id}|${currentMonth()}`);
    const tonsByGood = new Map(goods.common.map((good) => [good, rollNotation(rng, good.tons)]));
    for (let roll = 0, count = rollNotation(rng, rules.randomGoodsPerMarket); roll < count; roll++) {
      const good = rng.pick(goods.trade);
      tonsByGood.set(good, (tonsByGood.get(good) ?? 0) + rollNotation(rng, good.tons));
    }
    return [...tonsByGood].map(([good, tons]) => ({
      good, tonsAvailable: tons - (state.purchasedTons[purchaseKey(world, good)] ?? 0), buyPrice: pricePerTon(good, world, 'buy'),
    }));
  }

  function monthlyCosts() {
    return {
      mortgage: ship.purchasePrice / ship.mortgagePaymentDivisor,
      salaries: sum(Object.values(ship.crewMonthlySalaries)),
      lifeSupport: ship.staterooms * ship.lifeSupportPerStateroomPerMonth,
      maintenance: (ship.purchasePrice * ship.maintenanceFractionOfPricePerYear) / 12,
    };
  }

  function advanceDays(days) {
    state.day += days;
    while (state.billedMonths < currentMonth() && !state.gameOver) {
      state.billedMonths++;
      state.cash -= sum(Object.values(monthlyCosts()));
      log(`Monthly bills paid. Cash ${formatCredits(state.cash)}.`);
      if (state.cash < 0) state.gameOver = 'Bankrupt: the bank repossesses the ship.';
    }
  }

  function buy(goodName, tons) {
    requireThat(!state.gameOver, 'The game is over.');
    const lot = marketLots(currentWorld()).find((candidate) => candidate.good.name === goodName);
    requireThat(Number.isInteger(tons) && tons > 0, 'Enter a whole number of tons.');
    requireThat(lot && tons <= lot.tonsAvailable, 'Not that many tons for sale.');
    requireThat(cargoTons() + tons <= ship.cargoTons, 'Not enough cargo space.');
    const cost = tons * lot.buyPrice;
    requireThat(cost <= state.cash, 'Not enough cash.');
    state.cash -= cost;
    const key = purchaseKey(currentWorld(), lot.good);
    state.purchasedTons[key] = (state.purchasedTons[key] ?? 0) + tons;
    const held = state.cargo[goodName] ?? { tons: 0, totalCost: 0 };
    state.cargo[goodName] = { tons: held.tons + tons, totalCost: held.totalCost + cost };
    log(`Bought ${tons}t ${goodName} for ${formatCredits(cost)}.`);
  }

  function sell(goodName, tons) {
    requireThat(!state.gameOver, 'The game is over.');
    const held = state.cargo[goodName];
    requireThat(Number.isInteger(tons) && tons > 0, 'Enter a whole number of tons.');
    requireThat(held && tons <= held.tons, 'You do not hold that many tons.');
    const good = allGoods.find((candidate) => candidate.name === goodName);
    const revenue = tons * pricePerTon(good, currentWorld(), 'sell');
    const costBasis = (held.totalCost * tons) / held.tons;
    state.cash += revenue;
    held.tons -= tons;
    held.totalCost -= costBasis;
    if (held.tons === 0) delete state.cargo[goodName];
    log(`Sold ${tons}t ${goodName} for ${formatCredits(revenue)} (profit ${formatCredits(revenue - costBasis)}).`);
  }

  const FUEL_SOURCES = {
    refined: { label: 'Buy refined', available: (world) => 'AB'.includes(world.starport), pricePerTon: () => rules.travel.refinedFuelCostPerTon },
    unrefined: { label: 'Buy unrefined', available: (world) => 'ABC'.includes(world.starport), pricePerTon: () => rules.travel.unrefinedFuelCostPerTon },
    skim: { label: 'Skim gas giant', available: (world) => world.hasGasGiant, pricePerTon: () => 0 },
  };

  /** Fills the tank from the given source. Mixing in any unrefined fuel makes the tank unrefined. */
  function refuel(sourceName) {
    const source = FUEL_SOURCES[sourceName];
    requireThat(source.available(currentWorld()), 'That fuel is not available here.');
    const tonsToAdd = ship.fuelTons - state.fuel.tons;
    requireThat(tonsToAdd > 0, 'The tank is already full.');
    const cost = tonsToAdd * source.pricePerTon();
    requireThat(cost <= state.cash, 'Not enough cash.');
    state.cash -= cost;
    state.fuel = { tons: ship.fuelTons, refined: state.fuel.refined && sourceName === 'refined' };
    log(`${source.label}: ${tonsToAdd}t for ${formatCredits(cost)}.`);
    if (sourceName === 'skim') advanceDays(rules.travel.daysPerGasGiantScoop);
  }

  function inspectArrival(world, rng) {
    if (rng.rollDice(2) >= world.lawLevel) return;
    for (const [goodName, held] of Object.entries(state.cargo)) {
      const good = allGoods.find((candidate) => candidate.name === goodName);
      if (good.bannedAtLawLevel === undefined || world.lawLevel < good.bannedAtLawLevel) continue;
      const fine = held.tons * good.basePrice * rules.law.fineFractionOfBasePrice;
      state.cash -= fine;
      delete state.cargo[goodName];
      log(`Inspection: ${held.tons}t ${goodName} seized, fined ${formatCredits(fine)}.`);
    }
  }

  function jump(destinationId) {
    requireThat(!state.gameOver, 'The game is over.');
    const distance = hexDistance(currentWorld(), worldById(destinationId));
    requireThat(distance >= 1 && distance <= ship.jumpRating, 'Destination is outside jump range.');
    const fuelNeeded = distance * ship.fuelTonsPerParsec;
    requireThat(state.fuel.tons >= fuelNeeded, `Jump needs ${fuelNeeded}t of fuel.`);

    const { travel } = rules;
    const rng = createRng(`${rules.seed}|event|${state.eventCount++}`);
    const jumpRoll = rng.rollDice(2) + travel.engineerJumpBonus + (state.fuel.refined ? 0 : travel.unrefinedFuelDM);
    const jumpDays = Math.round((148 + rng.rollDice(6)) / 24);
    const latenessDays = jumpRoll >= 8 ? 0 : jumpRoll >= 1 ? rng.rollDice(1) : 0;

    state.fuel.tons -= fuelNeeded;
    const arrival = jumpRoll <= 0 ? rng.pick(sector.worlds) : worldById(destinationId);
    state.locationId = arrival.id;
    state.cash -= travel.portFeePerArrival;
    advanceDays(jumpDays + latenessDays + travel.daysInSystemPerArrival);
    log(jumpRoll <= 0 ? `MISJUMP. Emerged at ${arrival.id}.` : `Arrived at ${arrival.id}${latenessDays ? `, ${latenessDays} days late` : ''}.`);
    inspectArrival(arrival, rng);
  }

  return { state, buy, sell, refuel, jump, marketLots, pricePerTon, monthlyCosts, cargoTons, currentWorld, worldById, allGoods, FUEL_SOURCES };
}
